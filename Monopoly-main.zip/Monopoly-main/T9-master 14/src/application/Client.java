package application;

public class Client {

	public static void main(String[] args) {
		Main UI = new Main();

		UI.beginGame(args);
	}
}