External .jar file dependencies: 
----------------------------------------   
Javafx: 15



How to run program: 
---------------------------------------- 
run Client.java, which contains the main() method    




Assignment Discussion: 
----------------------------------------    
Strong: We added error checks to make sure the game runs smoothly. Our Properties, RailRoad, and Utility have most of their functionality and error checks. 
Weak: We don't have a check to make sure that all the properties are owned in the color set. We don't track doubles for going to jail. 
Missing: We don't have trading functionality. We also don't have community chest or chance cards implemented.  

